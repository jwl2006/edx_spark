This project was originally hosted at
<https://code.google.com/archive/p/metric-learning/>. Google Code was
shut down, and the project does not seem to have been migrated
anywhere. This folder, and its contents, are a snapshot of the final
code from that repository (without commits).

The original project was released under the GNU GPL v3 license.
See [LICENSE.md](LICENSE.md) for details.
