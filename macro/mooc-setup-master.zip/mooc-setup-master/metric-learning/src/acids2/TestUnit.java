package acids2;

import acids2.output.Fscore;

public class TestUnit {
	
	protected Fscore fs;

	public Fscore getFs() {
		return fs;
	}

}
