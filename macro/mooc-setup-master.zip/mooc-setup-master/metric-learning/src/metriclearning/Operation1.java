package metriclearning;

public class Operation1 {
	
	private int arg1;
	private int arg2;
	private int n;
	
	public int getArg1() {
		return arg1;
	}

	public int getArg2() {
		return arg2;
	}

	public int getN() {
		return n;
	}

	public Operation1(int arg1, int arg2, int n) {
		this.arg1 = arg1;
		this.arg2 = arg2;
		this.n = n;
	}
	
}
